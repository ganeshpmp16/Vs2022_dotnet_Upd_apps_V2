﻿using ClassLibrary1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using ClassLibrary1;

namespace ConsoleAppClassLIb
{
    internal class Program
    {
        static void Main(string[] args)
        {Class1 class1 = new Class1();
             class1.Method1();
            Console.ReadLine();

        }
    }
}
