﻿using System;

namespace ConsoleApp_Upd
{
    // This is a simple console application that prints "Hello World!" to the console.
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadLine();
        }
    }
}
