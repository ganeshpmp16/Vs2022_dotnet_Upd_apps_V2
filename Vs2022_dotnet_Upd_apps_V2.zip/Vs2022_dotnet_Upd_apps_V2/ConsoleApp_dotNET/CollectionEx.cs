﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotNET
{
    internal class CollectionEx
    {
        // collectio expressions are a new feature in C# 12.0
        // that allow you to create collections using a more concise and readable syntax.
        // collection expression example for an array
        public void collectionExpressionExample()
        {
            // collection expression for an array
            int[] numbers = [1, 2, 3, 4, 5];
            // collection expression for a list
           // List<string> names = ["Alice", "Bob", "Charlie"];
            // collection expression for a dictionary
            //Dictionary<string, int> ages = ["Alice": 30, "Bob": 25, "Charlie": 35];
            Console.WriteLine("Collection expression example:");
            foreach (var number in numbers)
            {
                Console.WriteLine(number);
            }
        }
        static void Main(string[] args)
        {
            CollectionEx collectionEx = new CollectionEx();
            collectionEx.collectionExpressionExample();
            Console.ReadLine();
        }
    }
}
