﻿namespace ConsoleApp_dotNET
{
    internal class Program
    {
        //public class Person
        //{
        //    public string name;
        //    // constructor is a special method
        //    // that is called when an object of the class is created.
        //    // It is used to initialize the object.
        //    //public Person(string name)
        //    //{
        //    //    this.name = name;
        //    //}
        //    //  c# 12.0 supports primary constructors,
        //    //  which allow you to define a constructor directly in the class declaration.
        //    //  This can make your code more concise and easier to read.


        //}
        // primary constructor syntax
        public class Person(string name)
        {
            // The primary constructor automatically creates a constructor that takes the specified parameters
            // and initializes the corresponding fields or properties.
            // In this case, it will create a constructor that takes a string parameter and initializes the 'name' field.
            // You can also define additional members in the class as needed.
           public string Name = name;
           public void getName()
            {
                Console.WriteLine(Name);
            }

            // This creates a read-only property that returns the value of the 'name' parameter.
        }
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            Person person = new Person("John");
            person.getName();
            Console.ReadLine();

        }
    }
}
