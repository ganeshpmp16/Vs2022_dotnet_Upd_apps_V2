﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Dynamic_var_samples
    {// sample program to demonstrate the use of dynamic and var keywords in C#
        public static void Main(string[] args)
        {
            // using var keyword to declare a variable with implicit type which checks at compile time
            // what is an implicit type?
            // An implicit type is a type that is inferred by the compiler based on the value assigned to the variable.
            var x =10 ; // x is inferred to be of type int
           // int a = 10;
            Console.WriteLine($"x is {x} and its type is {x.GetType()}"); // output: x is 10 and its type is System.Int32
            // using dynamic keyword to declare a variable with dynamic type
            dynamic y=20 ; // y is of type dynamic, it can hold any type of value which checks at runtime
            Console.WriteLine($"y is {y} and its type is {y.GetType()}"); // output: y is 20 and its type is System.Int32
            // changing the value of y to a string
           // y = "Hello"; // now y holds a string value
            Console.WriteLine($"y is {y} and its type is {y.GetType()}"); // output: y is Hello and its type is System.String
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            object obj = 10; // obj is of type object, it can hold any type of value but it checks at compile time
            Console.WriteLine($"obj is {obj} and its type is {obj.GetType()}"); 
            // output: obj is 10 and its type is System.Int32
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            // boxing and unboxing 
                int a = 10; // a is of type int
                object obj1 = a; // boxing: converting a value type to a reference type
                Console.WriteLine($"obj1 is {obj1} and its type is {obj1.GetType()}"); // output: obj1 is 10 and its type is System.Int32
                int b = (int)obj1; // unboxing: converting a reference type back to a value type
                Console.WriteLine($"b is {b} and its type is {b.GetType()}"); // output: b is 10 and its type is System.Int32
                Console.WriteLine("Press any key to exit...");
                Console.ReadLine();
            // var usage in anonymous types
            var person = new { Name = "John", Age = 30 }; // person is an anonymous type with properties Name and Age
            Console.WriteLine($"Name: {person.Name}, Age: {person.Age}"); // output: Name: John, Age: 30
             Console.WriteLine("Press any key to exit...");
        }
    }
}
