﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class ForLoop
    {
        // sample program to demonstrate the use of a for loop to print numbers from 1 to 10
        static void Main(string[] args)
        {
            Console.WriteLine("Numbers from 1 to 10:");
            int i;
            for (i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            // for each loop to iterate through an array of strings and print each element
            string[] fruits = { "Apple", "Banana", "Cherry", "Date", "Elderberry" };
            Console.WriteLine("Fruits:");
            foreach (string fruit in fruits)
            {
                Console.WriteLine(fruit);
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
