﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Is_As_Operator_Samples
    {
        // sample program to demonstrate the use of is and as operators in C#
        public static void Main(string[] args)
        {
            object obj = "Hello, World!"; // obj is of type object, it can hold any type of value
            // using is operator to check if obj is of type string
            if (obj is string str) // if obj is of type string, then str will be assigned the value of obj
            {
                Console.WriteLine($"obj is a string: {str}"); // output: obj is a string: Hello, World!
            }
            else
            {
                Console.WriteLine("obj is not a string");
            }
            // using as operator to cast obj to string
            string str2 = obj as string; // if obj can be cast to string, then str2 will be assigned the value of obj, otherwise str2 will be null
            
            if (str2 != null)
            {
                Console.WriteLine($"obj can be cast to string: {str2}"); // output: obj can be cast to string: Hello, World!
            }
            else
            {
                Console.WriteLine("obj cannot be cast to string");
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            // another example to demonstrate the use of is operator with pattern matching
            int i = 34;
            object iBoxed = i;
            int? jNullable = 42;
            if (iBoxed is int a && jNullable is int b)
            {
                Console.WriteLine(a + b);  // output 76
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            // as operator example with nullable types
            object[] obj1 = new object[2];
            obj1[0] = "jack";
            obj1[1] = 32;

            for (int x = 0; x < obj1.Length; ++x)
            {
                string s = obj1[x] as string;
                Console.Write("{0}: ", x);
                if (s != null)
                    Console.WriteLine("'" + s + "'");
                else
                    Console.WriteLine("This is not a string!");
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();


        }
    }
}
