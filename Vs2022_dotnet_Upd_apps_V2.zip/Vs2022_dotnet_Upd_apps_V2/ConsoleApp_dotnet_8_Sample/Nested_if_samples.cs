﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Nested_if_samples
    {
        // sample program to demonstrate the use of nested if statements to determine the grade based on marks
        static void Main(string[] args)
        {
            // program to check student is eligible for exam based on attednance and fees paid
            Console.WriteLine("Enter the attendance percentage:");
            int attendance = Convert.ToInt32(Console.ReadLine());
            bool feesPaid = true; // assuming fees are paid for demonstration purposes
            if (attendance >= 75)
            {
                if (feesPaid)
                {
                    Console.WriteLine("Student is eligible for the exam.");
                }
                else
                {
                    Console.WriteLine("Student is not eligible for the exam due to unpaid fees.");
                }
            }
            else
            {
                Console.WriteLine("Student is not eligible for the exam due to low attendance.");
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
