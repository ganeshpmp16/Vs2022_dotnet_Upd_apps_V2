﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Null_coaleasing_Op_Sample
    {
        // sample program to demonstrate the use of  null coalescing operator to
        // provide a default value for a nullable variable
        public static void Main(string[] args)
        {
            //Console.WriteLine("Enter your name (or press Enter to skip):");
            //string ? name = Console.ReadLine();
            //string greeting= string.IsNullOrWhiteSpace(name) ? "Guest" : name;
            ////string greeting = $"Hello, {name ?? "Guest"}!";
            //Console.WriteLine("Hello "+greeting);
            //Console.WriteLine("Press any key to exit...");
            //Console.ReadLine();
            int? x = null;
            int y = x ?? -1; // ?? is the null coalescing operator, it returns the left-hand operand if it is not null, otherwise it returns the right-hand operand
            // x is the operand on the left-hand side of the ?? operator, and
            // -1 is the operand on the right-hand side of the ?? operator
            Console.WriteLine($"y is {y}");  // output: y is 30 
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            // null coealsing assignment operator (??=) is used
            // to assign a value to a variable if it is null
            string ?name = null;
            name ??= "Guest"; // if name is null, assign "Guest" to name
            Console.WriteLine($"Hello, {name}!"); // output: Hello, Guest!
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();

        }
    }
}
