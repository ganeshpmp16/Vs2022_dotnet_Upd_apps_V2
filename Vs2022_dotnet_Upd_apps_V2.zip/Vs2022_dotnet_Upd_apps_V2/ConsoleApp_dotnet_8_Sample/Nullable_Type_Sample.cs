﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Nullable_Type_Sample
    {
        // nullable type sample program to demonstrate the use of nullable types in C#
        // properties of nullable types:HasValue, Value, GetValueOrDefault(), GetValueOrDefault(T defaultValue), and ToString()

        public static void Main(string[] args)
        {
            // declare a nullable int variable
            // int ? nullableInt = null;
            Nullable<int> nullableInt = null;

            // check if the nullable int has a value
            if (nullableInt !=null)
            {
                Console.WriteLine("The value of nullableInt is: " + nullableInt.Value);
            }
            else
            {
                Console.WriteLine("nullableInt does not have a value.");
            }
            // assign a value to the nullable int
            nullableInt = 42;
            // check again if the nullable int has a value
            if (nullableInt.HasValue)
            {
                Console.WriteLine("The value of nullableInt is: " + nullableInt.Value);
            }
            else
            {
                Console.WriteLine("nullableInt does not have a value.");
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
