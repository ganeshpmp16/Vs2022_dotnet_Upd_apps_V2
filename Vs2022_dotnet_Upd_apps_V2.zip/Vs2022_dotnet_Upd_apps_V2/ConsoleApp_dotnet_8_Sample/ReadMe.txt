﻿// Advantages of using Switch expression over traditional if-else statements:
1. Conciseness: Switch expressions allow for a more concise syntax compared to traditional if-else statements.
They can often reduce the amount of code needed to achieve the same result.
2. Readability: Switch expressions can improve readability by providing a clear and structured way to handle multiple cases.
3. Pattern Matching: Switch expressions can utilize pattern matching, which allows for more complex conditions and can make the code easier to understand.
4. Less code ; No break statements
5. supporting r4elation checks(>=,< etc) 

intview question 
1. What is a switch expression in C# and how does it differ from a traditional switch statement?