﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Switch_Case_Sample_2
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter your marks:");
            int marks = Convert.ToInt32(Console.ReadLine());
            // switch expression to determine the grade based on marks
            string grade = marks switch
            {
                >= 90 => "A",
                >= 80 => "B",
                >= 70 => "C",
                >= 60 => "D",
                _ => "F"

            };
            Console.WriteLine(grade);
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
