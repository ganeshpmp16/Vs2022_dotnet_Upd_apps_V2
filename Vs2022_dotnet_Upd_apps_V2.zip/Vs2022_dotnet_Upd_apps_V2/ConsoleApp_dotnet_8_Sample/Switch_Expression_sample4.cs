﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Switch_Expression_sample4
    {
        // sample program to demonstrate the use of switch expression to determine the order status
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the order status:- New or Processing or cancelled or Delivered or shipping ");
            string statusMessage = Console.ReadLine();

            string orderStatus = statusMessage switch
            {
               "New" => "Your order has been placed.",
                "Processing" => "Your order is being processed.",
                "Shipped" => "Your order has been shipped.",
                "Delivered" => "Your order has been delivered.",
                "Cancelled" => "Your order has been cancelled.",
                _ => "Unknown order status."
            };
            Console.WriteLine(orderStatus);
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
