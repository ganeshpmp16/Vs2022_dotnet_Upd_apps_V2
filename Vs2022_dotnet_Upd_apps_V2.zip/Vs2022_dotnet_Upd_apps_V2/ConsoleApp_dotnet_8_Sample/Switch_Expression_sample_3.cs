﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Switch_Expression_sample_3
    {
        // using switch expression to determine the day of the week based on the day number
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the day number (1-7):");
            int dayNumber = Convert.ToInt32(Console.ReadLine());
            string dayOfWeek = dayNumber switch
            {
                1 => "Monday",
                2 => "Tuesday",
                3 => "Wednesday",
                4 => "Thursday",
                5 => "Friday",
                6 => "Saturday",
                7 => "Sunday",
                _ => "Invalid day number"
            };
            Console.WriteLine(dayOfWeek);
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }

    }
}
