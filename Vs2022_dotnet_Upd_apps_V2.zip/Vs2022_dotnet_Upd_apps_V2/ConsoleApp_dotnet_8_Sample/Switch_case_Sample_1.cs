﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Switch_case_Sample_1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your marks:");
            int marks = Convert.ToInt32(Console.ReadLine());
            switch (marks)
            {
                case int m when m >= 90:
                    Console.WriteLine("Grade: A");
                    break;
                case int m when m >= 80:
                    Console.WriteLine("Grade: B");
                    break;
                case int m when m >= 70:
                    Console.WriteLine("Grade: C");
                    break;
                case int m when m >= 60:
                    Console.WriteLine("Grade: D");
                    break;
                default:
                    Console.WriteLine("Grade: F");
                    break;
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
