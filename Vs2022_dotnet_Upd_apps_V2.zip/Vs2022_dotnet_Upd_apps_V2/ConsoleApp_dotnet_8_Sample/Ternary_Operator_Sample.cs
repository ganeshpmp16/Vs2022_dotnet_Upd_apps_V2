﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class Ternary_Operator_Sample
    {
        // sample program to demonstrate the use of ternary operator to determine if a number is even or odd
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter a number:");
            int number = Convert.ToInt32(Console.ReadLine());
            string result = (number % 2 == 0) ? "Even" : "Odd";
            Console.WriteLine($"The number {number} is {result}.");
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
