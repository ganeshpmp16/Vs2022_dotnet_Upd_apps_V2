﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class While_Loop
    {
        // sample program to demonstrate the use of a while loop to print numbers from 1 to 10
        // while loop is a control flow statement that allows code to be executed repeatedly based
        // on a given boolean condition. The loop continues to execute as long as the condition is true.
        // In this example, we will use a while loop to print numbers from 1 to 10.
        static void Main(string[] args)
        {
            Console.WriteLine("Numbers from 1 to 10:");
            int i = 1;
            while (i <= 10)
            {
                Console.WriteLine(i);
                i++;
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            // do while loop to print numbers from 1 to 10
            // do while loop is similar to a while loop,
            // but it guarantees that the code block will be executed at least once, even if the condition is false.
            // The condition is evaluated after the code block is executed.
            Console.WriteLine("Numbers from 1 to 10 using do-while loop:");
            int j = 1;
            do
            {
                Console.WriteLine(j);
                j++;
            } while (j <= 10);
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
