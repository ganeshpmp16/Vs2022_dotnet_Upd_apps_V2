﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_dotnet_8_Sample
{
    internal class value_type_ref_type_equality
    {
        // sample program to demonstrate the
        // equality of value types and reference types in C#
        public static void Main(string[] args)
        {
            int a = 5; // a is a value type
            int b = 5; // b is a value type
            Console.WriteLine(a == b); // output: True, because value types are compared by their values
            string s1 = "Hello"; // s1 is a reference type
            string s2 = "Hello"; // s2 is a reference type
            Console.WriteLine(s1 == s2); // output: True, because string literals are interned and refer to the same object in memory
            object o1 = new object(); // o1 is a reference type
            object o2 = new object(); // o2 is a reference type
            Console.WriteLine(o1 == o2); // output: False, because o1 and o2 refer to different objects in memory
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            Person p1 = new Person();
            p1.Name = "Alice";
            Person p2 = new Person();
            p2.Name = "Alice";
            Console.WriteLine(p1 == p2);            // output: False, because p1 and p2 refer to different objects in memory
            Console.WriteLine(p1.Name == p2.Name); // output: True, because the Name properties of p1 and p2 have the same value
            Console.WriteLine(p1.Equals(p2));       // output: False, because the default implementation of Equals for reference types compares references
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            object name = "James";
            char[] values = { 'J', 'a', 'm', 'e', 's' };
            object myName = new string(values);
            Console.WriteLine("== operator result is {0}", name == myName);
            Console.WriteLine("Equals method result is {0}", myName.Equals(name));
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();

        }
        class Person
        {
            public string Name;
        }
    }
}
