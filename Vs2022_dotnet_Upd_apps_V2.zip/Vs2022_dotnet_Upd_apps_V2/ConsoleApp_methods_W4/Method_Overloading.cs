﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_methods_W4
{
    internal class Method_Overloading
    {
        // Method overloading allows you to define multiple methods
        // with the same name but different parameters.
        static void Main(string[] args)
        {
            Console.WriteLine("Method Overloading Example:");
            Console.WriteLine(Add(5, 10)); // Calls the method with two integers
            Console.WriteLine(Add(5.5, 10.5)); // Calls the method with two doubles
            Console.WriteLine(Add("Hello, ", "World!")); // Calls the method with two strings
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
        static int Add(int a, int b)
        {
            return a + b;
        }
        static double Add(double a, double b)
        {
            return a + b;
        }
        static string Add(string a, string b)
        {
            return a + b;
        }
    }
}
