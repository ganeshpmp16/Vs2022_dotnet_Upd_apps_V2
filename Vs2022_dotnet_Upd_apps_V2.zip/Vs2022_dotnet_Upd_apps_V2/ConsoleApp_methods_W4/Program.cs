﻿using System.ComponentModel;

namespace ConsoleApp_methods_W4
{
    public class Program
    {
        //static  int Add(int a, int b)
        //{
        //    return a + b;
        //}
         static  void Main(string[] args)
        {
            int x = 5, y = 10;
            int c = Add(x, y);
            Console.WriteLine($"The sum of {x} and {y} is: {c}");
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            //  //  Program program = new Program();
            //   // int c= program.Add(x, y);
            //  //  Console.WriteLine($"The sum of {x} and {y} is: {c}");
            ////int c= Add(x, y);
            ////Console.WriteLine($"The sum of {x} and {y} is: {c}");
            //Console.WriteLine("Press any key to exit...");
            //Console.ReadKey();
            

        }
        
        private static int Add(int x, int y)
        {
            return x + y;
        }
        // create a method that takes two integers as parameters and returns their sum

    }
}
