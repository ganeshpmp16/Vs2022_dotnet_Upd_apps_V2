﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_methods_W4
{
    internal class Ref_Method_Sample
    {
        // Ref method sample
        static void Main(string[] args)
        {
            int a = 5, b = 10;
            Console.WriteLine($"Before calling the method: a = {a}, b = {b}");
            Swap(ref  a, ref b);
            Console.WriteLine($"After calling the method: a = {a}, b = {b}");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
        static void Swap(ref int x, ref int y)
        {
            int temp = x;
            x = y;
            y = temp;
        }

    }
}
