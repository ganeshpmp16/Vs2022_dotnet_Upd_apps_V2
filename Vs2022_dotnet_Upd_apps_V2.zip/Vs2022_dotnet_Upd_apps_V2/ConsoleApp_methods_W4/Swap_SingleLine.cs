﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_methods_W4
{
    internal class Swap_SingleLine
    {
        static void Main(string[] args)
        {  // Single line swap using tuple deconstruction ,c# 7.0 and later
            int a = 5, b = 10;

            Console.WriteLine($"Before swapping: a = {a}, b = {b}");
            (a, b) = (b, a); // Single line swap using tuple deconstruction

            Console.WriteLine($"After swapping: a = {a}, b = {b}");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
