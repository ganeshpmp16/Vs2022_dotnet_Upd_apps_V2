﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_methods_W4
{
    internal class tryparse_with_Out_sample
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number:");
            string input = Console.ReadLine();
            // Using TryParse with an out parameter to safely convert the input to an integer
            ParseValue(input);
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        private static void ParseValue(string input)
        {
            if (int.TryParse(input, out int result))
            {
                Console.WriteLine($"You entered the number: {result}");
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
            }
        }
    }
}
