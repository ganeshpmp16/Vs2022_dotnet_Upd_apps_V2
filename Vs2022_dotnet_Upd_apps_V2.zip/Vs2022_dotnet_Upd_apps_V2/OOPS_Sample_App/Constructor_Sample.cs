﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    class Product
    {
        //auto-implemented properties
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        // Constructor
        public Product()
        {
            // default constructor as well as empty constructor
            Console.WriteLine("Default constructor called. Product object created.");
        }
        // parameterized constructor to initialize the properties of the Product
        // class when an object is created. It takes three parameters: id, name, and price,
        // which are used to set the values of the Id, Name, and Price properties respectively.
        
        // overloaded constructor
        public Product(int id, string name, double price)
        {
            Id = id;
            Name = name;
            Price = price;
        }
        // below is a finalizer for the Product class.
        // A finalizer is a special method that is called when an object is being garbage collected.
        // It is used to perform any necessary cleanup before the object is removed from memory. In this case, the finalizer simply writes a message to the console indicating that the finalizer is executing for the Product object.
        // below expression-bodied member for finalizer used 
        ~Product() => Console.WriteLine($"The {ToString()} finalizer is executing.");
        public void DisplayProductDetails()
        {
            Console.WriteLine($"Product ID: {Id}");
            Console.WriteLine($"Product Name: {Name}");
            //Console.WriteLine($"Product Price: {Price:C}");
            Console.WriteLine("Product Price : " + Price.ToString("C", CultureInfo.CreateSpecificCulture("en-US")));
           // Console.WriteLine("Product Price: {0:C}");
        }
    }
    internal class Constructor_Sample
    {
        static void Main(string[] args)
        {
            // creating an object of the Product class using the default constructor
            Product defaultProduct = new Product();
            defaultProduct.DisplayProductDetails();
            // creating an object of the Product class using the parameterized constructor
            Product objProduct = new Product(1, "Laptop", 999.99);
            objProduct.DisplayProductDetails();
            GC.Collect(); // Force garbage collection to see the finalizer in action
            GC.WaitForPendingFinalizers(); // Wait for the finalizer to complete
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
