﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    class Employee
    {
        private string name;
        private int age;
        private string department;
        public void SetEmployeeDetails(string name, int age, string department)
        {
            this.name = name;
            this.age = age;
            this.department = department;
        }
        // constructor usage 
        //public Employee(string name, int age, string department)
        //{
        //    this.name = name;
        //    this.age = age;
        //    this.department = department;
        //}
        public void DisplayEmployeeDetails()
        {
            Console.WriteLine($"Employee Name: {name}");
            Console.WriteLine($"Employee Age: {age}");
            Console.WriteLine($"Employee Department: {department}");
        }
    }
    internal class Employee_Display
    { 
        static void Main(string[] args)
        {
            // Employee objEmployee = new Employee("Alice", 28, "HR");
            Employee objEmployee = new Employee();
            objEmployee.SetEmployeeDetails("Alice", 28, "HR");
            objEmployee.DisplayEmployeeDetails();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }


    }
}
