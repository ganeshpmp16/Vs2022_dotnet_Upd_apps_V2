﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    // Hierarchical inheritance is a type of inheritance in object-oriented programming where multiple derived classes inherit from a single base class. In this type of inheritance, the base class serves as a common ancestor for all the derived classes,
    // allowing them to share common properties and behaviors while also having their own unique features.
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("Animal is eating.");
        }
    }
    public class Tiger : Animal
    {
        public void Roar()
        {
            Console.WriteLine("Tiger is roaring.");
        }
    }
    public class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine("Cat is meowing.");
        }
    }
    class Heirarchical_Inheritance
    {
        static void Main(string[] args)
        {
            Tiger objTiger = new Tiger();
            objTiger.Eat(); // Inherited method from Animal class
            objTiger.Roar(); // Tiger's own method
            Cat objCat = new Cat();
            objCat.Eat(); // Inherited method from Animal class
            objCat.Meow(); // Cat's own method
            Console.WriteLine("Press any key to exit...");
                        Console.ReadKey();
        }
    }
}
