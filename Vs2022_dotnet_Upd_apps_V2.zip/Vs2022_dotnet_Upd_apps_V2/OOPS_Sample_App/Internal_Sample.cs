﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    internal class Customer
    {
        public void DisplayCustomer()
        {
            Console.WriteLine("This is a customer class.");
        }

    }
    class Internal_Sample
    {
        static void Main(string[] args)
        {
            Customer objCustomer = new Customer();
            objCustomer.DisplayCustomer();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
