﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    // Method overriding is a feature in object-oriented programming that allows a subclass (derived class) to provide
    // a specific implementation of a method that is already defined in its superclass (base class).

    public class BaseClass
    {
        public virtual void Display()
        {
            Console.WriteLine("This is the base class method.");
        }
    }
    public class DerivedClass : BaseClass
    {
        public override void Display()
        {
            Console.WriteLine("This is the derived class method, overriding the base class method.");
        }
    }
    internal class Method_Overiding_Sample
    {
        static void Main(string[] args)
        {
            BaseClass objBase = new BaseClass();
            objBase.Display(); // Output: This is the base class method.
            DerivedClass ObjDerived = new DerivedClass();
            ObjDerived.Display(); // Output: This is the derived class method, overriding the base class method.
                                  // Polymorphism in action
           
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}

