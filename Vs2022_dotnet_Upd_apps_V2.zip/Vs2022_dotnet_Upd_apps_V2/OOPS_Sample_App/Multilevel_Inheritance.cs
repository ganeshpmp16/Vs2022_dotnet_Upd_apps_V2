﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    // Multilevel inheritance is a type of inheritance in object-oriented programming
    // where a class is derived from another class, which is itself derived from another class.
    // In this type of inheritance, there is a chain of inheritance where each class inherits from the previous class in the hierarchy.
     public class A
    {
        public int x { get; set; }
        public void MethodA()
        {
            Console.WriteLine("This is method A.");
        }
    }
    public class B : A
    {
        public void MethodB()
        {
            Console.WriteLine("This is method B.");
        }
    }
    public class C : B
    {
        public void MethodC()
        {
            x=10; // accessing the property x inherited from class A
            Console.WriteLine($"Value of x inherited from class A: {x}");
            Console.WriteLine("This is method C.");
        }
    }
    internal class Multilevel_Inheritance
    {
        static void Main(string[] args)
        {
            C objC = new C();

            objC.x = 5; // Accessing the property x inherited from class A
            Console.WriteLine($"Value of x set in class C: {objC.x}");
            objC.MethodA(); // Inherited from class A
            objC.MethodB(); // Inherited from class B
            objC.MethodC(); // Method of class C
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
