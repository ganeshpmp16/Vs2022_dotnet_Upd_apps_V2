﻿namespace OOPS_Sample_App
{
    // class is a blueprint for creating objects.
    // clsss is a single unit of code that encapsulates data and behavior related to a specific concept or entity.
    // It defines properties and methods that the objects created from the class will have.
    class Person
    {
        // data members or fields
        private string name;
        private int age;

        // member functions or methods
        public  void Introduce()
        {
            this.name = "John"; 
            this.age = 30;
            Console.WriteLine($"Hello, my name is {name} and I am {age} years old.");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            // creating an object or instance  of the class
            Person objPerson = new Person();
            // new keyword is used to create an instance of the class
            // what does new do ? new keyword allocates memory for the object
            // and returns a reference to that memory location.
            // It also calls the constructor of the class to initialize the object.
            objPerson.Introduce();
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
