﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    internal class Property_Sample
    {
        // properties are a way to encapsulate data and provide controlled access to it.
        // properties are defined using get and set accessors, which allow you to specify how the property can be accessed and modified.
        // this exmaple demonstrates how to use properties to encapsulate the name and age of a person.
            private string _name;
            private int _age;
    
            // property for name
            public string Name
            {
            get { return _name; }
            set { _name = value; }
            //get => _name; // expression-bodied member for get accessor
            //set => _name = value; // expression-bodied member for set accessor
            //get { return this._name; }
        }
    
            // property for age
            public int Age
            {
                get { return _age; }

            set { if (value >= 0) _age = value; }
                                                    
            }
    
            static void Main(string[] args)
            {
            //Property_Sample obj = new Property_Sample();
            //obj.Name = "Alice";
            //obj.Age = -28;
            // object initializer syntax
            Property_Sample objEmp = new Property_Sample { 
                    
                    Name = "Alice", Age = -28 
                };

           // Console.WriteLine($"Name: {obj.Name}");
             //   Console.WriteLine($"Age: {obj.Age}");
    
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
        }
    }
}
