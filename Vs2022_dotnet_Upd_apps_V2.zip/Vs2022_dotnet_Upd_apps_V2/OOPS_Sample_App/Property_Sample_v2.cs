﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{ // to demonstrate the use of auto implemented properties for a bank account class. The BankAccount class has two auto implemented properties: AccountNumber and Balance. The Main method creates an instance of the BankAccount class, sets the properties, and displays their values.

    public class BankAccount
    {
        // Auto implemented properties
        // are a shorthand syntax for defining properties in C#.
        // They allow you to quickly create properties
        // without having to write the backing field
        // and the get/set accessors explicitly.
        // The compiler automatically generates the backing field for you.
        public string AccountNumber { get; set; }
        public string AccountName { get; set; }
        public decimal Balance { get; set; }
        // to display the details of the bank account method is created below
        public void DisplayAccountDetails()
        {
            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Account Name: {AccountName}");
            Console.WriteLine($"Balance: {Balance:C}");
        }

    }
    internal class Property_Sample_v2
    {
        static void Main(string[] args)
        {  
            // instance of the BankAccount class is created
            // and the properties are set using object initializer syntax.
            // The DisplayAccountDetails method is called to display the account details on the console.
            BankAccount objAccount = new BankAccount
            {
                AccountNumber = "123456789",
                AccountName = "John Doe",
                Balance = 1000.50m
            };
            objAccount.DisplayAccountDetails();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
