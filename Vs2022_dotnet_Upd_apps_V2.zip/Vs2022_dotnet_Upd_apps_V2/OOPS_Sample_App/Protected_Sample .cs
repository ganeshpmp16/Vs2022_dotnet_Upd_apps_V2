﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    // The 'protected' access modifier allows access to members of a class within the same class and by derived classes.

    public class MyBankAccount
    {
        protected decimal balance;
        public MyBankAccount(decimal initialBalance)
        {
            balance = initialBalance;
        }
        protected void Deposit(decimal amount)
        {
            // balance = balance + amount; // This is equivalent to balance += amount;
            balance += amount;
        }
        protected void Withdraw(decimal amount)
        {
            if (amount <= balance)
            {
                balance -= amount;
            }
            else
            {
                Console.WriteLine("Insufficient funds.");
            }
        }
    }
    public class SavingsAccount : MyBankAccount
    {
        public SavingsAccount(decimal initialBalance) : base(initialBalance)
        {
        }
        public void AddInterest(decimal interestRate)
        {
            decimal interest = balance * interestRate;
            Deposit(interest); // Using the protected Deposit method from the base class
            Console.WriteLine($"Interest added: {interest:C}. New balance: {balance:C}");
        }
    }

    internal class Protected_Sample
    {
        static void Main(string[] args)
        {
            SavingsAccount mySavings = new SavingsAccount(1000);
            mySavings.AddInterest(0.05m); // Adding 5% interest
            // The balance is not directly accessible here because it's protected,
            // but we can use the AddInterest method to modify it.
            Console.WriteLine("Interest added to the savings account.");
            Customer objCust = new Customer();
            objCust.DisplayCustomer();

            Console.WriteLine("Press Enter to exit.");  
            Console.ReadLine();
        }

    }
}
