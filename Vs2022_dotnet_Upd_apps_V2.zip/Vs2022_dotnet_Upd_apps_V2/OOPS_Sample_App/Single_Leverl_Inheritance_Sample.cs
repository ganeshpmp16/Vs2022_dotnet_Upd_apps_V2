﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Sample_App
{
    // Single level inheritance is a fundamental concept in object-oriented programming (OOP)
    // that allows a new class (called a derived class or child class) to inherit
    // properties and behaviors (fields and methods)
    // from an existing class (called a base class or parent class).
    public class MyPerson
    {
        
        public int Age { get; set; }
        public int height { get; set; }
        public double weight { get; set; }
        public void DisplayPerson()
        {
            Console.WriteLine($" The age of the Person is {Age},weight is {weight} and height is {height}");
        }
    }
    public class MyEmployee : MyPerson
    {
        public string EmployeeID { get; set; }
        public int salary { get; set; }
        public string EmployeeDepartment { get; set; }
        public void DisplayEmployee()
        {
            DisplayPerson(); // calling the method from the base class to display person details
            Console.WriteLine($"Employee ID: {EmployeeID}");
            Console.WriteLine($"Employee Salary: {salary}");
            Console.WriteLine($"Employee Department: {EmployeeDepartment}");
        }
    }
    internal class Single_Leverl_Inheritance_Sample
    {
        static void Main(string[] args)
        {
            // Creating an instance of the MyEmployee class and setting its properties
            // The MyEmployee class inherits properties and methods from the MyPerson class,
            // so we can set the properties of MyPerson as well as MyEmployee.
            // object initializer syntax is used to set the properties of the MyEmployee object in a concise way.

            MyEmployee objEmployee = new MyEmployee
            {
                Age = 30,
                height = 175,
                weight = 70.5,
                EmployeeID = "E12345",
                salary = 50000,
                EmployeeDepartment = "IT"
            };
            objEmployee.DisplayEmployee();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
